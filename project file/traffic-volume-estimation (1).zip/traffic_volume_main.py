from src.preprocess import load_and_preprocess
from src.model import train_model
import matplotlib.pyplot as plt
import seaborn as sns

# Load and preprocess data
X, y = load_and_preprocess('data/Metro_Interstate_Traffic_Volume.csv')

# Train model
model, mse, r2, y_test, y_pred = train_model(X, y)

print(f"Mean Squared Error: {mse}")
print(f"R^2 Score: {r2}")

# Plot actual vs predicted
plt.figure(figsize=(10,5))
sns.scatterplot(x=y_test, y=y_pred)
plt.xlabel("Actual Traffic Volume")
plt.ylabel("Predicted Traffic Volume")
plt.title("Actual vs Predicted Traffic Volume")
plt.grid(True)
plt.show()
