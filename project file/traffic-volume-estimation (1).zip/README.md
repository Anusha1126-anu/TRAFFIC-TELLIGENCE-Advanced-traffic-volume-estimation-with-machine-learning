# Traffic Volume Estimation using Machine Learning

This project predicts hourly traffic volume using weather, time, and holiday data. It uses a linear regression model as a baseline and can be extended with more advanced ML models.

## 📊 Dataset

- Metro Interstate Traffic Volume
- Source: [UCI ML Repository](https://archive.ics.uci.edu/ml/datasets/Metro+Interstate+Traffic+Volume)

## 🚀 Getting Started

### Requirements
```bash
pip install -r requirements.txt
```

### Run Script
```bash
python traffic_volume_main.py
```

### Run Jupyter Notebook
```bash
jupyter notebook notebooks/traffic_volume_prediction.ipynb
```

## 📁 Project Structure
- `src/`: Source code for preprocessing and model training
- `data/`: Dataset CSV file
- `notebooks/`: Jupyter Notebook version of the pipeline
