import pandas as pd

def load_and_preprocess(filepath):
    df = pd.read_csv(filepath)
    df['date_time'] = pd.to_datetime(df['date_time'])
    df['hour'] = df['date_time'].dt.hour
    df['dayofweek'] = df['date_time'].dt.dayofweek

    df = df.drop(['date_time', 'weather_description'], axis=1)
    df = pd.get_dummies(df, columns=['weather_main', 'holiday'], drop_first=True)

    X = df.drop('traffic_volume', axis=1)
    y = df['traffic_volume']

    return X, y
